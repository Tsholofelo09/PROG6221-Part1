﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App
{
    internal class Program
    {
        static List<Recipe> recipes = new List<Recipe>();
        static Recipe currentRecipe;
        static void Main(string[] args)
        {
            {//add ingredient
                List<Recipe> recipes = new List<Recipe>();

                while (true)
                {
                    Console.WriteLine("Enter a recipe name (or 'exit' to quit):");
                    string recipeName = Console.ReadLine();
                    if (recipeName.ToLower() == "exit")
                    {
                        break;
                    }

                    Recipe recipe = new Recipe(recipeName);

                    Console.WriteLine("Enter the number of ingredients:");
                    int numIngredients = int.Parse(Console.ReadLine());

                    for (int i = 0; i < numIngredients; i++)
                    {
                        Console.WriteLine("Ingredient " + (i + 1) + ":");
                        Console.Write("Name: ");
                        string name = Console.ReadLine();
                        Console.Write("Quantity: ");
                        double quantity = double.Parse(Console.ReadLine());
                        Console.Write("Unit: ");
                        string unit = Console.ReadLine();
                        Console.Write("Calories: ");
                        double calories = double.Parse(Console.ReadLine());
                        Console.Write("Food group: ");
                        string foodGroup = Console.ReadLine();

                        recipe.Ingredients.Add(new Ingredient(name, quantity, unit, calories, foodGroup));
                    }

                    Console.WriteLine("Enter the number of steps:");
                    int numSteps = int.Parse(Console.ReadLine());

                    for (int i = 0; i < numSteps; i++)
                    {
                        Console.WriteLine("Step " + (i + 1) + ":");
                        string step = Console.ReadLine();

                        recipe.Steps.Add(step);
                    }

                    recipes.Add(recipe);

                    Console.WriteLine();
                }
                //sorting of recipes
                recipes.Sort((a, b) => a.Name.CompareTo(b.Name));

                while (true)
                {
                    Console.WriteLine("Select a recipe to display (or 'exit' to quit):");
                    for (int i = 0; i < recipes.Count; i++)
                    {
                        Console.WriteLine((i + 1) + ". " + recipes[i].Name);
                    }
                    string input = Console.ReadLine();
                    if (input.ToLower() == "exit")
                    {
                        break;
                    }
                    int index = int.Parse(input);





                }
            }
        }
    }
}

        
