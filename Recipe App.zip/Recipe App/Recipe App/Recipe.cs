﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Recipe_App
{

    internal class Recipe
    {
        public string Name;
        public List<Ingredient> Ingredients;
        public List<string> Steps;

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<string>();
        }
        // calculation of calories
        public double TotalCalories()
        {
            double total = 0;
            foreach (var ingredient in Ingredients)
            {
                total += ingredient.Calories;
            }
            return total;
        }
        //display recipe
        public void DisplayRecipe()
        {
            Console.WriteLine(Name);
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in Ingredients)
            {
                Console.WriteLine("- " + ingredient.Quantity + " " + ingredient.Unit + " " + ingredient.Name + " (" + ingredient.Calories + " calories, " + ingredient.FoodGroup + ")");
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < Steps.Count; i++)
            {
                Console.WriteLine((i + 1) + ". " + Steps[i]);
            }
            Console.WriteLine();
        }



    }
}





